# Local training notes

Intentionally vulnerable demo with synthetic data only. Uses Python standard library, no installation required.

Run `python3 app.py` inside the Strix sandbox. Listens on 127.0.0.1:8765 only. The simulated current user is Alice. Alice should see only Alice's notes; Bob's note is private. Routes are listed at `/`.

Do not deploy this training app. No real credentials or data are present.
